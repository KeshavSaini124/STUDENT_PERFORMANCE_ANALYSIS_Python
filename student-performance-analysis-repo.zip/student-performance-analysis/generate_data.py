"""Creates student_data.csv - a sample student dataset (with some dirty values on purpose)."""
import numpy as np
import pandas as pd

np.random.seed(42)
n = 200
df = pd.DataFrame({
    "StudentID": np.arange(1, n + 1),
    "Gender": np.random.choice(["Male", "Female"], n),
    "Section": np.random.choice(["A", "B", "C"], n),
    "StudyHours": np.random.normal(4, 1.5, n).clip(0.5, 9).round(1),
    "Attendance": np.random.normal(78, 12, n).clip(35, 100).round(0),
})
base = 12 + 6 * df["StudyHours"] + 0.25 * df["Attendance"]
for sub in ["Maths", "Physics", "Chemistry", "English", "Computer"]:
    df[sub] = (base + np.random.normal(0, 8, n)).clip(0, 100).round(0)
df.loc[df.Gender == "Female", "English"] += 5          # small gender effect
df["English"] = df["English"].clip(0, 100)

# make the data "dirty" like real-world data
df["Attendance"] = df["Attendance"].astype(int).astype(str) + "%"   # wrong type
df.loc[np.random.choice(n, 8, replace=False), "Maths"] = np.nan       # missing
df.loc[np.random.choice(n, 6, replace=False), "Attendance"] = np.nan  # missing
idx = np.random.choice(n, 12, replace=False)                          # inconsistent
df.loc[idx[:6], "Gender"] = df.loc[idx[:6], "Gender"].str.lower()
df.loc[idx[6:], "Gender"] = df.loc[idx[6:], "Gender"].str[0]
df = pd.concat([df, df.sample(5, random_state=1)], ignore_index=True)  # duplicates
df.to_csv("student_data.csv", index=False)
print("student_data.csv created with", len(df), "rows")
