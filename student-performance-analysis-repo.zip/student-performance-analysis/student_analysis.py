"""Student Performance Data Analysis - Pandas, NumPy, Matplotlib, Seaborn."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid")
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 20)
subjects = ["Maths", "Physics", "Chemistry", "English", "Computer"]

# ---------------- 1. LOAD DATA ----------------
df = pd.read_csv("student_data.csv")
print("Shape :", df.shape)
print(df.head())
df.info()

# ---------------- 2. DATA CLEANING ----------------
print("\nMissing values:\n", df.isnull().sum())
print("Duplicate rows:", df.duplicated().sum())
print("Gender values before:", df["Gender"].unique().tolist())

df = df.drop_duplicates()
df["Attendance"] = df["Attendance"].str.replace("%", "").astype(float)
df["Maths"] = df["Maths"].fillna(df["Maths"].median())
df["Attendance"] = df["Attendance"].fillna(df["Attendance"].median())
df["Gender"] = df["Gender"].str.title().replace({"M": "Male", "F": "Female"})

print("\nAfter cleaning -> missing:", df.isnull().sum().sum(),
      "| duplicates:", df.duplicated().sum())
print("Gender values after:", df["Gender"].unique().tolist())

# ---------------- 3. ANALYSIS ----------------
df["Total"] = df[subjects].sum(axis=1)
df["Percentage"] = df["Total"] / 5
df["Result"] = np.where((df[subjects] >= 40).all(axis=1), "Pass", "Fail")
df["Grade"] = pd.cut(df["Percentage"], [0, 40, 50, 60, 70, 100],
                     labels=["F", "D", "C", "B", "A"])

print("\nMean   :", round(np.mean(df["Percentage"]), 2))
print("Median :", round(np.median(df["Percentage"]), 2))
print("Std dev:", round(np.std(df["Percentage"]), 2))
print("\n", df[subjects].describe().round(2))
print("\nGender-wise average:\n", df.groupby("Gender")[subjects + ["Percentage"]].mean().round(2))
print("\nSection-wise average:\n", df.groupby("Section")["Percentage"].mean().round(2))
print("\nTop 5 students:\n", df.sort_values("Percentage", ascending=False)
      [["StudentID", "Gender", "Section", "Percentage"]].head(5))
print("\nAttendance below 60% :", len(df[df["Attendance"] < 60]), "students")
print("\nResult count:\n", df["Result"].value_counts())
corr = df[["StudyHours", "Attendance"] + subjects + ["Percentage"]].corr()
print("\nCorrelation with Percentage:\n", corr["Percentage"].round(2))

# ---------------- 4. VISUALIZATION ----------------
def save(name):
    plt.tight_layout()
    plt.savefig(f"charts/{name}.png", dpi=110)
    plt.close()
    print("Saved charts/" + name + ".png")

# Matplotlib
df.groupby(df["StudyHours"].round())["Percentage"].mean().plot(marker="o")
plt.title("Average Percentage vs Study Hours"); plt.xlabel("Study hours"); plt.ylabel("Percentage")
save("1_line_chart")

df[subjects].mean().plot(kind="bar", color="steelblue")
plt.title("Average Marks per Subject"); plt.ylabel("Marks")
save("2_bar_chart")

plt.hist(df["Percentage"], bins=12, color="orange", edgecolor="black")
plt.title("Distribution of Percentage"); plt.xlabel("Percentage"); plt.ylabel("Students")
save("3_histogram")

df["Grade"].value_counts().sort_index().plot(kind="pie", autopct="%1.0f%%")
plt.title("Grade Distribution"); plt.ylabel("")
save("4_pie_chart")

plt.scatter(df["Attendance"], df["Percentage"], alpha=0.6, color="green")
plt.title("Attendance vs Percentage"); plt.xlabel("Attendance (%)"); plt.ylabel("Percentage")
save("5_scatter_plot")

# Seaborn
sns.boxplot(data=df[subjects]); plt.title("Subject-wise Marks (Box Plot)")
save("6_box_plot")

sns.violinplot(x="Section", y="Percentage", data=df); plt.title("Percentage by Section")
save("7_violin_plot")

sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm"); plt.title("Correlation Heatmap")
save("8_heatmap")

sns.countplot(x="Grade", hue="Gender", data=df, order=["F", "D", "C", "B", "A"])
plt.title("Grades by Gender")
save("9_count_plot")

sns.pairplot(df[["StudyHours", "Attendance", "Percentage"]])
plt.savefig("charts/10_pair_plot.png", dpi=90); plt.close()
print("Saved charts/10_pair_plot.png")
