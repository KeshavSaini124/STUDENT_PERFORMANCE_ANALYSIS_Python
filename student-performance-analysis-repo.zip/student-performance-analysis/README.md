# Student Performance Analysis (Data Science Mini Project)

Case study on **"What factors are associated with students' academic performance?"**
using Pandas, NumPy, Matplotlib and Seaborn.

**Submitted by:** Keshav Saini (UID: 25BCD10101)

## Files
| File | Purpose |
|------|---------|
| `generate_data.py` | Creates `student_data.csv` (sample data with missing values, duplicates and inconsistent entries) |
| `student_analysis.py` | Cleaning, analysis and 10 charts |
| `student_data.csv` | Dataset (205 rows, 10 columns) |
| `charts/` | The 10 charts produced (Matplotlib + Seaborn) |
| `report/` | Case study and mini project report (Word) |

## What it does
1. **Cleaning** - missing values, duplicates, wrong data types, inconsistent gender values
2. **Analysis** - mean/median/std, group-by, sorting, filtering, correlation
3. **Charts** - line, bar, histogram, pie, scatter, box, violin, heatmap, count plot, pair plot

## Run
```
pip install -r requirements.txt
python generate_data.py      # optional - csv is already included
python student_analysis.py
```

## Key findings
- Study hours has the strongest link with marks (correlation 0.85)
- Attendance has a weak effect (0.29)
- Pass rate is 78.5% (157 of 200 students)
